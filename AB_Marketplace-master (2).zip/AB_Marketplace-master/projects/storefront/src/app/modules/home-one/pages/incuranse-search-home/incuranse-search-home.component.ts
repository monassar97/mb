import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incuranse-search-home',
  templateUrl: './incuranse-search-home.component.html',
  styleUrls: ['./incuranse-search-home.component.scss']
})
export class IncuranseSearchHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
