import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-peoperty-search-home',
    templateUrl: './peoperty-search-home.component.html',
    styleUrls: ['./peoperty-search-home.component.scss'],
})
export class PeopertySearchHomeComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
