import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-search-home',
  templateUrl: './travel-search-home.component.html',
  styleUrls: ['./travel-search-home.component.scss']
})
export class TravelSearchHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
