import { TestBed } from '@angular/core/testing';

import { CheckboxDispatcherService } from './checkbox-dispatcher.service';

describe('CheckboxDispatcherService', () => {
    let service: CheckboxDispatcherService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(CheckboxDispatcherService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
