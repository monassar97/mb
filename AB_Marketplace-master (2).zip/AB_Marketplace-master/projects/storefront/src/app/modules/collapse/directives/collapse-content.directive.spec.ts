import { CollapseContentDirective } from './collapse-content.directive';

describe('CollapseContentDirective', () => {
  it('should create an instance', () => {
    const directive = new CollapseContentDirective();
    expect(directive).toBeTruthy();
  });
});
