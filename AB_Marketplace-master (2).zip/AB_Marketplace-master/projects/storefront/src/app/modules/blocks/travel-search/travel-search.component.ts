import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-search',
  templateUrl: './travel-search.component.html',
  styleUrls: ['./travel-search.component.scss']
})
export class TravelSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
