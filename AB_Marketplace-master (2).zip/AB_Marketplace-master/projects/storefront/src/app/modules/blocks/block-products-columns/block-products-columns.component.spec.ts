import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockProductsColumnsComponent } from './block-products-columns.component';

describe('BlockProductsColumnsComponent', () => {
    let component: BlockProductsColumnsComponent;
    let fixture: ComponentFixture<BlockProductsColumnsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ BlockProductsColumnsComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BlockProductsColumnsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
