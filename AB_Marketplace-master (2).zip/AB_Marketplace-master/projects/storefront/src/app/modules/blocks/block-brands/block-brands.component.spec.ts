import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockBrandsComponent } from './block-brands.component';

describe('BlockBrandsComponent', () => {
    let component: BlockBrandsComponent;
    let fixture: ComponentFixture<BlockBrandsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ BlockBrandsComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BlockBrandsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
