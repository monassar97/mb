import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockSaleComponent } from './block-sale.component';

describe('BlockSaleComponent', () => {
    let component: BlockSaleComponent;
    let fixture: ComponentFixture<BlockSaleComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ BlockSaleComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BlockSaleComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
