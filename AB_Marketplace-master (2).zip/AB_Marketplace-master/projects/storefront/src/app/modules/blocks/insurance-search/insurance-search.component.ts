import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurance-search',
  templateUrl: './insurance-search.component.html',
  styleUrls: ['./insurance-search.component.scss']
})
export class InsuranceSearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
