import { TestBed } from '@angular/core/testing';

import { ServerLoaderService } from './server-loader.service';

describe('ServerLoaderService', () => {
    let service: ServerLoaderService;

    beforeEach(() => {
        TestBed.configureTestingModule({});
        service = TestBed.inject(ServerLoaderService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
