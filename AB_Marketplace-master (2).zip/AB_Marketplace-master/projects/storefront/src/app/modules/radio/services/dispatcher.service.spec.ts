import { TestBed } from '@angular/core/testing';

import { DispatcherService } from './dispatcher.service';

describe('DispatcherService', () => {
    beforeEach(() => TestBed.configureTestingModule({}));

    it('should be created', () => {
        const service: DispatcherService = TestBed.get(DispatcherService);
        expect(service).toBeTruthy();
    });
});
