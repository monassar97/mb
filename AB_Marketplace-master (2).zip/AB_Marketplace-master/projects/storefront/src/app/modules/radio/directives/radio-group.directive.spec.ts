import { RadioGroupDirective } from './radio-group.directive';

describe('RadioGroupDirective', () => {
    it('should create an instance', () => {
        const directive = new RadioGroupDirective(null);
        expect(directive).toBeTruthy();
    });
});
