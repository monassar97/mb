import { RemoveFromWishlistDirective } from './remove-from-wishlist.directive';

describe('RemoveFromWishlistDirective', () => {
    it('should create an instance', () => {
        const directive = new RemoveFromWishlistDirective(null, null);
        expect(directive).toBeTruthy();
    });
});
