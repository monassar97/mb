import { RemoveVehicleDirective } from './remove-vehicle.directive';

describe('RemoveVehicleDirective', () => {
    it('should create an instance', () => {
        const directive = new RemoveVehicleDirective();
        expect(directive).toBeTruthy();
    });
});
