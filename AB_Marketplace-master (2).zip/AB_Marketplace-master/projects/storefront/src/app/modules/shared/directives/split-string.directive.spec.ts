import { SplitStringDirective } from './split-string.directive';

describe('SplitStringDirective', () => {
    it('should create an instance', () => {
        const directive = new SplitStringDirective();
        expect(directive).toBeTruthy();
    });
});
