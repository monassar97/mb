import { AddToCompareDirective } from './add-to-compare.directive';

describe('AddToCompareDirective', () => {
    it('should create an instance', () => {
        const directive = new AddToCompareDirective();
        expect(directive).toBeTruthy();
    });
});
