import { RemoveFromCompareDirective } from './remove-from-compare.directive';

describe('RemoveFromCompareDirective', () => {
    it('should create an instance', () => {
        const directive = new RemoveFromCompareDirective();
        expect(directive).toBeTruthy();
    });
});
