import { AddVehicleDirective } from './add-vehicle.directive';

describe('AddVehicleDirective', () => {
    it('should create an instance', () => {
        const directive = new AddVehicleDirective();
        expect(directive).toBeTruthy();
    });
});
