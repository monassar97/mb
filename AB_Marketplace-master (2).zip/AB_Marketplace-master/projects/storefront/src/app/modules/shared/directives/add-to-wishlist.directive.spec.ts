import { AddToWishlistDirective } from './add-to-wishlist.directive';

describe('AddToWishlistDirective', () => {
    it('should create an instance', () => {
        const directive = new AddToWishlistDirective();
        expect(directive).toBeTruthy();
    });
});
