import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShareLinksComponent } from './share-links.component';

describe('ShareLinksComponent', () => {
    let component: ShareLinksComponent;
    let fixture: ComponentFixture<ShareLinksComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ ShareLinksComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ShareLinksComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
