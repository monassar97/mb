import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageAddressesComponent } from './page-addresses.component';

describe('PageAddressesComponent', () => {
    let component: PageAddressesComponent;
    let fixture: ComponentFixture<PageAddressesComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ PageAddressesComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(PageAddressesComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
