import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-cars-product',
    templateUrl: './cars-product.component.html',
    styleUrls: ['./cars-product.component.scss'],
})
export class CarsProductComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
