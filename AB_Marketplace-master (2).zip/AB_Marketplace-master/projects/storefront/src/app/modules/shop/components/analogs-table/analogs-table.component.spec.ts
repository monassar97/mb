import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalogsTableComponent } from './analogs-table.component';

describe('AnalogsTableComponent', () => {
    let component: AnalogsTableComponent;
    let fixture: ComponentFixture<AnalogsTableComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ AnalogsTableComponent ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AnalogsTableComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
