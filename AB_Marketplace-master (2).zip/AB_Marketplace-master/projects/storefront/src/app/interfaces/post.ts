export interface Post {
    id: number;
    title: string;
    image: string;
    categories: string[];
    date: string;
}
