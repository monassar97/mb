export interface Vehicle {
    id: number;
    year: number;
    make: string;
    model: string;
    engine: string;
}
